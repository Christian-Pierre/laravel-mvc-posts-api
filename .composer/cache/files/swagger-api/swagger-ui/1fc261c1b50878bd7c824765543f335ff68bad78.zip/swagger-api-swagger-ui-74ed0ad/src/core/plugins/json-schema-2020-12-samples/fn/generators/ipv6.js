/**
 * @prettier
 */
const ipv6Generator = () => "2001:0db8:5b96:0000:0000:426f:8e17:642a"

export default ipv6Generator
